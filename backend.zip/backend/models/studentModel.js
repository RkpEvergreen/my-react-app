import db from "../config/db.js";

export const insertStudent = (data, callback) => {
  const sql = "INSERT INTO add_new_student SET ?";
  db.query(sql, data, callback);
};

export const fetchAllStudents = (callback) => {
  const sql = "SELECT * FROM add_new_student";
  db.query(sql, callback);
};
