import express from "express";
import { addStudent, getAllStudents } from "../controllers/studentController.js";
import upload from "../middleware/upload.js";

const router = express.Router();

router.post("/add", upload.single("photo"), addStudent);
router.get("/", getAllStudents);

export default router;
