import { insertStudent, fetchAllStudents } from "../models/studentModel.js";
import path from "path";
import fs from "fs";

export const addStudent = (req, res) => {
  const { body, file } = req;

  if (!file) {
    return res.status(400).json({ error: "Photo upload is required" });
  }

  const studentData = {
    ...body,
    photo: file.filename,
  };

  insertStudent(studentData, (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Student added successfully", data: result });
  });
};

export const getAllStudents = (req, res) => {
  fetchAllStudents((err, students) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ students });
  });
};
